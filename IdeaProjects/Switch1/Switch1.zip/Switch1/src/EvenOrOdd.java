//a program to check whether number is even or odd

public class EvenOrOdd
{
    public static void main(String[] args)//main method
    {

        int num=10;//declaring variable
        switch (num % 2)//using switch statement
        {
            case 0:
                System.out.println("is a even number");//printing out  even number
             break;
            case 1:
                System.out.println(" is a odd number");//printing out odd number

        }



    }
}
