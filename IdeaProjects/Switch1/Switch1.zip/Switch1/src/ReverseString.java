//a program is print the reverse string

public class ReverseString {
    public static void main(String[] args)//main method
    {
        String initial = "fedcba";//user have to enter string name


        switch (initial)//creating switch statement
        {
            case "fedcba":
                System.out.println("Enter string name:");

            case "abcdef":
                System.out.println("The reverse of the string abcdef is fedcba !");
             break;
        }
    }


}












