//a program to check greater number
public class GreatestAndLargest
{
    public static void main(String[] args)//main method
    {

        int i= 3;//creating variable

     switch (i)//creating switch statement
     {
         case  1:
             System.out.println("1 is smaller number");//printing out small number
             break;
         case 2:
             System.out.println("2 is smaller number");//printing out small number

             break;
         case 3:
             System.out.println("3 number is greatest number");//printing out greatest number

     }


    }
}
